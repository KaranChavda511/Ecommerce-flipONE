// src/routes/UserRoutes/UserRoutes.js
import express from 'express';
import { protect, userProtect } from '../../middlewares/AuthMiddleware.js';
import {
  userSignup,
  userLogin,
  getUserProfile,
  updateProfile,
  updateprofilePic,
} from '../../controllers/UserControllers/UserController.js';
import { errorHandler } from '../../middlewares/ErrorMiddleware.js';
import { profileImageUpload } from '../../utils/FileUploads.js';
import {validator} from '../../middlewares/ValidationMiddleware.js'

const router = express.Router();

// Apply authentication middleware to all routes
// router.use(protect, userProtect,);

// Define routes

// User Signup
router.post(
  "/signup",
  validator("userSchemas.signup"),
  userSignup
);

// User Login
router.post(
  "/login",
  validator("userSchemas.login"),
  userLogin
);

router.get('/profile' ,protect, userProtect, getUserProfile);
router.patch('/profile',protect, userProtect,validator("userSchemas.updateProfile"), updateProfile); 
router.patch('/profile/picture', 
  protect, userProtect,
  profileImageUpload,
  updateprofilePic
);


// Global error handler (must be the last middleware)
router.use(errorHandler);

export default router;